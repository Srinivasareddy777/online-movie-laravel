<script type="text/javascript">
            $(function () {
                $('#datetime').datetimepicker();
            });
        </script>