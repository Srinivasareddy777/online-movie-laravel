
            $(function () {
                $('#datetime').datetimepicker();
                format: 'LT'
            });
       