<head>

     
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" type="text/css">
     <link rel="stylesheet" type="text/css" href="signup.css">  
         
</head> 