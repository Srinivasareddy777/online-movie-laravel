<html>
<head>
</head>
<body>
additioin is {{$var1 + $var2}}<br>
subtractioin is {{$var1 - $var2}}<br>
multiplication is {{$var1 * $var2}}<br>
division is {{$var1 / $var2}}<br>
</body>