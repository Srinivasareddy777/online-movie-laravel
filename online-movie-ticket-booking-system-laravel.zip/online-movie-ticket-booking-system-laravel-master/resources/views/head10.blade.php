<head>
<link rel="icon" href="img/webpic.ico">
    <meta name="viewport" content="width=device-width height=device-height">
    <link rel="stylesheet" href="bootstrap/css/bootstrap.min.css" type="text/css">
        <script type="text/javascript" src="bootstrap/js/jquery.js"></script>
        <script type="text/javascript" src="bootstrap/js/bootstrap.min.js"></script>
        <script type="text/javascript" src="image.js"></script>
                <script type="text/javascript" src="html2canvas.js"></script>
</head>       
